import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createZip } from './zip.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const downloads = join(root, 'public/downloads');
await mkdir(downloads, { recursive: true });
await copyFile(join(root, 'exports/LaoDing-个人网站.html'), join(downloads, 'laoding-portfolio.html'));
await copyFile(join(root, 'exports/laoding-portfolio-source.zip'), join(downloads, 'laoding-portfolio-source.zip'));
await copyFile(join(root, 'exports/LICENSE.txt'), join(downloads, 'LICENSE.txt'));
console.log('HTML and MIT-licensed source downloads prepared.');

const htmlFiles = ['LaoDing-个人网站.html', 'LICENSE.txt', '使用说明.txt'];
const entries = await Promise.all(htmlFiles.map(async name => ({ name, data: await readFile(join(root, 'exports', name)) })));
const htmlArchive = createZip(entries);
await writeFile(join(root, 'exports/laoding-portfolio-html.zip'), htmlArchive);
await writeFile(join(downloads, 'laoding-portfolio-html.zip'), htmlArchive);
