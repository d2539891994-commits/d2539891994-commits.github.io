import { readFile, readdir, mkdir, writeFile } from 'node:fs/promises';
import { createZip } from './zip.mjs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const files = [];
const roots = ['src', 'scripts', 'public'];
const topLevel = ['index.html', 'package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'tailwind.config.js', 'postcss.config.js', '.gitignore', 'LICENSE', 'README.md', 'docs/ASSETS.md'];
async function walk(relative) {
  for (const entry of await readdir(join(root, relative), { withFileTypes: true })) {
    if (entry.name === 'downloads' || entry.name.startsWith('.')) continue;
    const path = `${relative}/${entry.name}`;
    if (entry.isDirectory()) await walk(path);
    else if (entry.isFile()) files.push(path);
  }
}
for (const dir of roots) await walk(dir);
for (const file of topLevel) {
  try { await readFile(join(root, file)); files.push(file); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
}
files.sort();
const entries = await Promise.all(files.map(async relative => ({ name: `laoding-portfolio/${relative}`, data: await readFile(join(root, relative)) })));
const archive = createZip(entries);
await mkdir(join(root, 'exports'), { recursive: true });
await writeFile(join(root, 'exports/laoding-portfolio-source.zip'), archive);
console.log(JSON.stringify({ sourceArchive: 'exports/laoding-portfolio-source.zip', files: files.length, bytes: archive.length }));
