import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';

const projectDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const sourceDir = resolve(process.argv[2] || projectDir);
const outputDir = resolve(process.argv[3] || join(projectDir, 'exports'));
const require = createRequire(join(sourceDir, 'package.json'));
const ts = require('typescript');
const viteDir = dirname(require.resolve('vite/package.json'));
const { build } = await import(pathToFileURL(join(viteDir, 'dist/node/index.js')));
const assetData = new Map();
const usedAssets = new Set();
const mimeTypes = { '.webp': 'image/webp', '.png': 'image/png', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.mp4': 'video/mp4', '.vtt': 'text/vtt' };

async function collect(dir, prefix = '') {
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const relative = `${prefix}/${entry.name}`;
    if (entry.isDirectory()) await collect(join(dir, entry.name), relative);
    else if (mimeTypes[extname(entry.name)]) {
      const bytes = await readFile(join(dir, entry.name));
      assetData.set(relative, `data:${mimeTypes[extname(entry.name)]};base64,${bytes.toString('base64')}`);
    }
  }
}
await collect(join(sourceDir, 'public'));

const embeddedPlugin = {
  name: 'laoding-standalone-html',
  enforce: 'pre',
  transform(original, id) {
    if (!id.startsWith(join(sourceDir, 'src') + '/') || !/\.(tsx?|json)$/.test(id)) return null;
    let code = original;
    if (id.endsWith('/lib/navigation.ts')) {
      code = code.replace('=> `/work/${project.id}/`', '=> `#work/${project.id}`');
      code = code.replace('"/#projects"', '"#projects"');
    }
    if (id.endsWith('/components/CaseShare.tsx')) {
      code = code.replace('onClick={async () => {', 'onClick={async () => {\n        if (window.location.protocol === "file:") { setMessage("请发送此 HTML 文件"); return; }');
      code = code.replace('window.location.origin', 'window.location.href');
    }
    if (id.endsWith('.json')) {
      code = code.replace(/"(\/images\/[^"\\]+)"/g, (match, name) => {
        if (!assetData.has(name)) throw new Error(`Missing asset: ${name}`);
        usedAssets.add(name);
        return JSON.stringify(assetData.get(name));
      });
      return { code, map: null };
    }
    const sf = ts.createSourceFile(id, code, ts.ScriptTarget.Latest, true, id.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS);
    const edits = [];
    function visit(node) {
      if (ts.isStringLiteral(node) || ts.isNoSubstitutionTemplateLiteral(node)) {
        if (/^\/(images|media)\//.test(node.text)) {
          if (!assetData.has(node.text)) throw new Error(`Missing asset: ${node.text}`);
          usedAssets.add(node.text);
          let replacement = `__LAODING_ASSET__(${JSON.stringify(node.text)})`;
          if (ts.isJsxAttribute(node.parent)) replacement = `{${replacement}}`;
          edits.push({ start: node.getStart(sf), end: node.end, text: replacement });
        }
      } else if (ts.isTemplateExpression(node) && node.head.text === '/images/portfolio/') {
        for (const name of assetData.keys()) if (name.startsWith('/images/portfolio/')) usedAssets.add(name);
        edits.push({ start: node.getStart(sf), end: node.end, text: `__LAODING_ASSET__(${code.slice(node.getStart(sf), node.end)})` });
      }
      ts.forEachChild(node, visit);
    }
    visit(sf);
    edits.sort((a, b) => b.start - a.start);
    for (const edit of edits) code = code.slice(0, edit.start) + edit.text + code.slice(edit.end);
    return { code, map: null };
  },
};

process.chdir(sourceDir);
const result = await build({
  root: sourceDir,
  configFile: false,
  plugins: [embeddedPlugin],
  define: { 'process.env.NODE_ENV': '"production"', 'import.meta.env.VITE_STANDALONE_HTML': '"true"' },
  build: {
    write: false,
    copyPublicDir: false,
    target: 'es2020',
    minify: 'esbuild',
    sourcemap: false,
    cssCodeSplit: false,
    lib: { entry: join(sourceDir, 'src/main.tsx'), name: 'LaoDingPortfolio', formats: ['iife'] },
    rollupOptions: { onwarn(warning, warn) { if (warning.code !== 'MODULE_LEVEL_DIRECTIVE') warn(warning); } },
  },
});
const outputs = (Array.isArray(result) ? result : [result]).flatMap(item => item.output);
const js = outputs.filter(item => item.type === 'chunk').map(item => item.code).join('\n');
let css = outputs.filter(item => item.type === 'asset' && item.fileName.endsWith('.css')).map(item => typeof item.source === 'string' ? item.source : Buffer.from(item.source).toString()).join('\n');
if (!js || !css) throw new Error('Expected a complete JavaScript and CSS bundle.');
css = css.replace(/url\((['"]?)(\/fonts\/[^)'"\s]+)\1\)/g, (_match, _quote, name) => {
  if (!assetData.has(name)) throw new Error(`Missing font: ${name}`);
  usedAssets.add(name);
  return `url("${assetData.get(name)}")`;
});
if (/url\(\s*['"]?\/(?:fonts|images|media)\//.test(css)) throw new Error('A CSS asset was not embedded.');
const inlineAssets = Object.fromEntries([...usedAssets].filter(name => !name.startsWith('/fonts/')).map(name => [name, assetData.get(name)]));
const fontLicense = await readFile(join(sourceDir, 'public/fonts/OFL-Kanit.txt'), 'utf8');
const codeLicense = await readFile(join(sourceDir, 'LICENSE'), 'utf8');
const escapeScript = value => value.replace(/<\/script/gi, '<\\/script');
const runtime = `(() => {\nconst assets = ${JSON.stringify(inlineAssets)};\nconst blobs = new Map();\nfunction __LAODING_ASSET__(name) {\n  const value = assets[name];\n  if (!value) throw new Error('Missing embedded asset: ' + name);\n  if (!name.startsWith('/media/')) return value;\n  if (!blobs.has(name)) {\n    const comma = value.indexOf(',');\n    const mime = value.slice(5, value.indexOf(';'));\n    const binary = atob(value.slice(comma + 1));\n    const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));\n    blobs.set(name, URL.createObjectURL(new Blob([bytes], { type: mime })));\n  }\n  return blobs.get(name);\n}\n${js}\n})();`;
const html = `<!doctype html>\n<html lang="zh-CN">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<meta name="theme-color" content="#0C0C0C">\n<meta name="description" content="LaoDing 的个人空间：内容创作、交互工具与持续探索中的个人实践。">\n<title>LaoDing — 个人网站</title>\n<link rel="icon" type="image/svg+xml" href="${assetData.get('/favicon.svg')}">\n<style>${css.replace(/<\/style/gi, '<\\/style')}</style>\n</head>\n<body>\n<div id="root"></div>\n<noscript>请在浏览器中启用 JavaScript，以查看 LaoDing 的个人网站与交互作品集。</noscript>\n<script>${escapeScript(runtime)}</script>\n<!-- Page code license; personal images and third-party portfolio media are excluded.\n${codeLicense.replaceAll('-->', '-- >')}\nKanit font license:\n${fontLicense.replaceAll('-->', '-- >')}\n-->\n</body>\n</html>\n`;
await mkdir(outputDir, { recursive: true });
const output = join(outputDir, 'LaoDing-个人网站.html');
await writeFile(output, html);
await writeFile(join(outputDir, 'LICENSE.txt'), codeLicense + '\n\nKanit font license:\n' + fontLicense);
await writeFile(join(outputDir, '使用说明.txt'), `LaoDing 个人网站 · 单文件 HTML 版\n\n1. 双击“LaoDing-个人网站.html”，使用 Chrome、Edge 或 Safari 打开。\n2. 图片、字体、样式、脚本和 CHROMA 操作演示已打包在同一个文件里；查看网页内容无需代理，也不需要安装 Node.js。\n3. 点击作品卡片查看内容归档、原图与案例；可以正常返回。\n4. CONTACT ME 保留联系弹窗，联系方式按原要求留空。\n5. 飞书原文档与 CHROMA 在线编辑器是外部链接，打开它们仍需要网络；HTML 文件不包含独立视频编辑器本体。\n6. 要发给别人本地查看，直接发送此 HTML 文件。它不是新的公网网址；若需通过一个公开链接访问，仍需上传到静态网站托管。\n7. 自有页面代码沿用 MIT 许可，字体沿用 SIL OFL；本人肖像、作品截图及第三方媒体不适用 MIT 代码许可。\n\n此文件为离线 HTML 导出；公开访问请使用站主提供的实际发布网址。\n`);
await writeFile(join(outputDir, 'export-manifest.json'), JSON.stringify({ file: 'LaoDing-个人网站.html', bytes: Buffer.byteLength(html), assetCount: usedAssets.size, assets: [...usedAssets].sort(), routing: 'same-file hash', externalRuntimeDependencies: [], publicDeployment: false }, null, 2) + '\n');
console.log(JSON.stringify({ output, bytes: Buffer.byteLength(html), embeddedAssets: usedAssets.size, standalone: true }));
