import { readFile, writeFile, mkdir } from "node:fs/promises";
import ts from "typescript";
const source = await readFile(
  new URL("../src/data/content.ts", import.meta.url),
  "utf8",
);
const js = ts.transpileModule(source, {
  compilerOptions: {
    module: ts.ModuleKind.ESNext,
    target: ts.ScriptTarget.ES2022,
  },
}).outputText;
const { projects } = await import(
  `data:text/javascript;base64,${Buffer.from(js).toString("base64")}`
);
const configuredOrigin = process.env.SITE_ORIGIN?.trim();
const originUrl = configuredOrigin ? new URL(configuredOrigin) : null;
if (originUrl && !["http:", "https:"].includes(originUrl.protocol)) {
  throw new Error("SITE_ORIGIN must be an HTTP or HTTPS website origin.");
}
const origin = originUrl?.origin;
const root = new URL("../dist/", import.meta.url);
const html = await readFile(new URL("index.html", root), "utf8");
const escape = (value) =>
  value
    .replaceAll("&", "&amp;")
    .replaceAll('"', "&quot;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
for (const project of projects) {
  const title = escape(`${project.name} — LaoDing`);
  const description = escape(project.description);
  const url = origin ? new URL(`/work/${project.id}/`, origin).href : null;
  let page = html
    .replace(/<title>.*?<\/title>/s, `<title>${title}</title>`)
    .replace(
      /(<meta\s+name="description"\s+content=")[^"]*"/s,
      `$1${description}"`,
    )
    .replace(/(<meta\s+property="og:title"\s+content=")[^"]*"/s, `$1${title}"`)
    .replace(
      /(<meta\s+property="og:description"\s+content=")[^"]*"/s,
      `$1${description}"`,
    );
  if (url) page = page.replace("</head>", `<meta property="og:url" content="${escape(url)}" /><link rel="canonical" href="${escape(url)}" /></head>`);
  const target = new URL(`work/${project.id}/`, root);
  await mkdir(target, { recursive: true });
  await writeFile(new URL("index.html", target), page);
}
if (origin) {
  const url = escape(`${origin}/`);
  await writeFile(new URL("index.html", root), html.replace("</head>", `<meta property="og:url" content="${url}" /><link rel="canonical" href="${url}" /></head>`));
}
console.log(`Static case entry pages written: ${projects.length}`);
