import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

const project = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const input = resolve(process.argv[2] || join(project, 'exports/LaoDing-个人网站.html'));
const out = resolve(process.argv[3] || join(project, 'online'));
await mkdir(out, { recursive: true });
const html = await readFile(input, 'utf8');
let runtime = html.match(/<script>([\s\S]*?)<\/script>/)[1];
let css = html.match(/<style>([\s\S]*?)<\/style>/)[1];
const start = runtime.indexOf('const assets = ') + 'const assets = '.length;
const end = runtime.indexOf(';\nconst blobs', start);
const embedded = JSON.parse(runtime.slice(start, end));
const mimeExtensions = { 'image/webp': 'webp', 'image/png': 'png', 'image/svg+xml': 'svg', 'font/woff2': 'woff2', 'video/mp4': 'mp4', 'text/vtt': 'vtt' };
const written = new Map();
async function externalize(value) {
  if (written.has(value)) return written.get(value);
  const match = /^data:([^;]+);base64,([\s\S]+)$/.exec(value);
  if (!match || !mimeExtensions[match[1]]) throw Error('Unsupported embedded asset');
  const bytes = Buffer.from(match[2], 'base64');
  const name = `portfolio-${createHash('sha256').update(bytes).digest('hex').slice(0, 16)}.${mimeExtensions[match[1]]}`;
  await writeFile(join(out, name), bytes);
  written.set(value, './' + name);
  return './' + name;
}
const assets = {};
for (const [name, value] of Object.entries(embedded)) assets[name] = await externalize(value);
const bundleStart = runtime.indexOf('(function(){', end);
if (bundleStart < 0) throw Error('Application bundle not found');
runtime = `(() => {\nconst assets = ${JSON.stringify(assets)};\nfunction __LAODING_ASSET__(name) { return assets[name] || name; }\n` + runtime.slice(bundleStart);
for (const value of [...new Set((runtime + css).match(/data:(?:image\/[a-z+.-]+|font\/woff2|video\/mp4|text\/vtt);base64,[A-Za-z0-9+/=]+/g) || [])]) {
  const path = await externalize(value);
  runtime = runtime.replaceAll(value, path);
  css = css.replaceAll(value, path);
}
// Older embedded browsers can still browse the static page if application code fails.
runtime = `if (!Array.prototype.at) Object.defineProperty(Array.prototype,'at',{value:function(i){i=Math.trunc(i)||0;return this[i<0?this.length+i:i];},configurable:true,writable:true});\n` + runtime;
const appName = `portfolio-app-${createHash('sha256').update(runtime).digest('hex').slice(0, 16)}.js`;
await writeFile(join(out, appName), runtime);
const escape = s => s.replaceAll('&', '&amp;').replaceAll('"', '&quot;').replaceAll('<', '&lt;');
const image = name => escape(assets[name]);
const fallback = `<div class="boot-static">
<section class="boot-hero" aria-label="LaoDing 个人网站">
<nav class="boot-nav" aria-label="主导航"><a href="#about">ABOUT</a><a href="#strengths">STRENGTHS</a><a href="#projects">PROJECTS</a><a href="./chroma.html">TOOLS ↗</a></nav>
<h1>HI, I'M LAODING</h1>
<img class="boot-person" src="${image('/images/laoding-full-body.webp')}" alt="LaoDing 的全身人物形象" width="1024" height="1536" fetchpriority="high">
<div class="boot-bottom"><div id="strengths"><small>核心优势 / CORE STRENGTHS</small><p>聚焦 AI 应用与商业认知类 IP，具备选题策划、脚本构建与后期制作能力。</p><p>擅长从用户需求与理解门槛出发，提炼内容切口、组织叙事结构，将专业知识转化为兼具信息价值与观看节奏的短视频内容。</p></div><a class="boot-contact" href="#contact-placeholder">CONTACT ME ↗</a></div>
</section>
<section id="projects" class="boot-section"><small>01 / SELECTED PROJECTS</small><h2>作品与项目。</h2><p>内容、工具，以及不断发生的探索。</p><div class="boot-projects"><a href="https://ucnbmn4swael.feishu.cn/wiki/N3eqwwrtFi29CEkfdDhcj6wln5b" target="_blank" rel="noopener"><h3>内容创作作品集 ↗</h3><p>教程作品、内容研究、分镜脚本与制作流程。</p></a><a href="./chroma.html"><h3>衣序 CHROMA 视频编辑器 ↗</h3><p>已有视频的播放、片段裁剪与导出。</p></a></div></section>
<section id="about" class="boot-section"><small>02 / A LITTLE ABOUT ME</small><h2>你好，我是 LaoDing。<br>关注工具，更关注表达。</h2><p>我关注 AI 应用与知识类内容，喜欢把复杂的工具和概念讲清楚，也喜欢把想法做成可以观看、阅读和使用的作品。</p><p id="contact-placeholder">联系方式稍后公开。</p></section></div>`;
const critical = `.boot-static{color:#d7e2ea;background:#0c0c0c;font-family:Kanit,system-ui,sans-serif}.boot-static a{color:inherit;text-decoration:none}.boot-hero{position:relative;min-height:760px;min-height:100svh;padding:26px 2.4vw 30px;display:flex;flex-direction:column;overflow:hidden}.boot-nav{display:flex;justify-content:space-between;font-size:clamp(11px,1.4vw,24px);font-weight:600;letter-spacing:.04em}.boot-hero h1{font-weight:900;font-size:12.4vw;line-height:1;white-space:nowrap;letter-spacing:-.06em;margin-top:34px;color:#bbccd7;background:linear-gradient(#646973,#bbccd7);-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}.boot-person{position:absolute;left:50%;top:19%;transform:translateX(-50%);height:72%;width:48%;object-fit:contain;pointer-events:none}.boot-bottom{margin-top:auto;display:flex;align-items:flex-end;justify-content:space-between;gap:24px;z-index:1;padding-top:380px}.boot-bottom>div{width:28%;font-size:clamp(12px,1.05vw,18px);line-height:1.9}.boot-bottom p{margin-top:14px}.boot-static small{font-size:10px;letter-spacing:.12em;color:#8e9098}.boot-contact{padding:16px 40px;border:2px solid white;border-radius:99px;background:linear-gradient(123deg,#18011f,#b600a8,#7621b0,#be4c00);font-size:13px;font-weight:600;letter-spacing:.12em}.boot-section{padding:100px 6vw;max-width:1440px;margin:auto}.boot-section h2{font-size:clamp(32px,5vw,72px);line-height:1.2;margin:20px 0}.boot-section>p{max-width:660px;color:#a5a6ac;line-height:1.8}.boot-projects{display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-top:36px}.boot-projects a{padding:36px;border:1px solid #4a405a;border-radius:28px;background:#18151d}.boot-projects h3{font-size:24px}.boot-projects p{margin-top:18px;color:#a5a6ac}.boot-notice{position:fixed;bottom:14px;left:14px;right:14px;z-index:500;max-width:500px;margin:auto;padding:12px 18px;border:1px solid #49414f;border-radius:15px;background:#19151fea;color:#d7e2ea;font:13px/1.6 system-ui}.boot-notice[hidden]{display:none}.boot-notice a{color:#d8c1ed;text-decoration:underline;margin-left:12px}.boot-downloads{padding:20px 6vw;color:#a5a6ac;font:12px/1.8 system-ui}.boot-downloads a{color:inherit;margin-right:24px}@media(max-width:700px){.boot-hero{padding:24px 22px 32px;min-height:844px;min-height:100svh}.boot-hero h1{font-size:12vw;margin-top:36px}.boot-person{top:130px;height:46%;width:74%}.boot-bottom{display:block;padding-top:430px}.boot-bottom>div{width:100%;font-size:13px;line-height:1.9}.boot-bottom p{margin-top:12px}.boot-contact{display:block;width:max-content;margin:24px 0 0 auto;padding:12px 24px}.boot-projects{grid-template-columns:1fr}.boot-section{padding:70px 22px}}`;
const boot = `(function(){var root=document.getElementById('root'),saved=root.innerHTML,note=document.getElementById('boot-notice'),loaded=false;function ready(){if(root.querySelector('.reference-hero,.case-page,.collection-page')){loaded=true;note.hidden=true;}}var observer=new MutationObserver(ready);observer.observe(root,{childList:true,subtree:true});window.addEventListener('error',function(){setTimeout(function(){if(!root.firstElementChild){root.innerHTML=saved;}if(!loaded)note.hidden=false;},0);});window.addEventListener('unhandledrejection',function(){if(!loaded)note.hidden=false;});setTimeout(function(){ready();if(!loaded)note.hidden=false;else observer.disconnect();},8000);})();`;
const page = `<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0C0C0C"><meta name="description" content="LaoDing 的个人空间：内容创作、交互工具与个人实践。"><title>LaoDing — 个人网站</title><style>html,body,#root{margin:0;background:#0c0c0c}*{box-sizing:border-box}${css}\n${critical}</style></head><body><div id="root">${fallback}</div><div id="boot-notice" class="boot-notice" hidden>互动内容暂未加载，可以先浏览作品。<a href="./?v=20261027">重新加载</a></div><nav class="boot-downloads" aria-label="开源与下载"><a href="./laoding-portfolio-source.zip">开源代码 · MIT ↗</a><a href="./laoding-portfolio-html.zip">下载 HTML ↗</a></nav><script>${boot}</script><script defer src="./${appName}" onerror="document.getElementById('boot-notice').hidden=false"></script><noscript><p class="boot-downloads">当前显示静态内容。启用 JavaScript 后可以使用人物互动和站内案例浏览。</p></noscript></body></html>`;
await writeFile(join(out, 'index.html'), page);
await writeFile(join(out, 'online-manifest.json'), JSON.stringify({ inputBytes: Buffer.byteLength(html), entryBytes: Buffer.byteLength(page), appBytes: Buffer.byteLength(runtime), appFile: appName, assetFiles: written.size, staticFallback: true }, null, 2));
console.log(JSON.stringify({ output: out, htmlBytes: Buffer.byteLength(page), scriptBytes: Buffer.byteLength(runtime), assets: written.size }));
