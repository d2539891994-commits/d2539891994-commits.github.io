/** Personal projects and the content collection imported from the user's Feishu document. */
export interface PortfolioImage {
  src: string;
  title: string;
  caption: string;
  shape: "portrait" | "wide" | "landscape";
  width?: number;
}
export interface Project {
  id: string;
  name: string;
  category: string;
  description: string;
  layout: "phones" | "research" | "tools" | "app" | "collection";
  collectionId?: string;
  images: PortfolioImage[];
  preview: number[];
  details: { title: string; text: string }[];
  report?: boolean;
  workflow?: boolean;
  liveUrl?: string;
  status?: string;
  sourceNote?: string;
}
export const siteConfig = {
  name: "LaoDing",
  title: "LaoDing — 个人网站",
  description:
    "LaoDing 的个人空间：内容创作、交互工具与持续探索中的个人实践。",
  sourceUrl: "https://ucnbmn4swael.feishu.cn/wiki/N3eqwwrtFi29CEkfdDhcj6wln5b",
};
const img = (
  file: string,
  title: string,
  caption: string,
  shape: PortfolioImage["shape"] = "portrait",
): PortfolioImage => ({
  src: `/images/portfolio/${file}.webp`,
  title,
  caption,
  shape,
  width:
    shape === "wide"
      ? file === "13-topics"
        ? 3921
        : file === "06-competitors"
          ? 3418
          : 3392
      : undefined,
});
export const accountImages: PortfolioImage[] = [
  img("01-account-bilibili", "Bilibili", "林粒粒呀 · B站账号主页"),
  img("02-account-xiaohongshu", "小红书", "林粒粒呀 · 小红书账号主页"),
  img("03-account-douyin", "抖音", "林粒粒呀 · 抖音账号主页"),
  img("04-account-wechat", "视频号", "林粒粒呀 · 微信视频号主页"),
];
const videos: PortfolioImage[] = [
  img(
    "12-codex-deepseek",
    "Codex 安装与国产大模型接入",
    "小白速通 Codex 安装 + 国产大模型接入 · 原始作品截图",
  ),
  img(
    "11-codex-tutorial",
    "Codex 安装与国产大模型接入 · Mac版",
    "Mac 安装与配置内容 · 原始作品截图，画面中的大数字为热度指数",
  ),
  img(
    "09-openclaw",
    "OpenClaw 保姆级安装教程",
    "Windows 安装与飞书接入 · 原始作品截图",
  ),
  img(
    "07-feishu-workflow",
    "从空白飞书到 AI 工作流",
    "AI 与办公场景的结合 · 原始作品截图",
  ),
  img(
    "08-voice-clone",
    "你的声音怎么被克隆的？",
    "声音克隆原理与技术演示 · 原始作品截图",
  ),
  img(
    "10-self-guide",
    "用 Skill 做高考志愿助手",
    "自我使用说明书式的交互内容 · 原始作品截图",
  ),
];
const research: PortfolioImage[] = [
  img(
    "05-audience",
    "受众画像",
    "受众来源、性别、年龄、地域等维度的原始数据截图",
  ),
  img(
    "06-competitors",
    "竞品账号分析",
    "账号信息、粉丝、互动与内容方向对照表",
    "wide",
  ),
  img("13-topics", "选题库", "竞品选题分析 · 原表横向完整截图", "wide"),
  img(
    "14-storyboard",
    "Codex 教程拆解分镜",
    "按参考视频原意整理的拆解分镜，含画面动作、文案与约略时间点",
    "wide",
  ),
];
const tools: PortfolioImage[] = [
  img(
    "17-extractor",
    "抖音主页视频数据抓取插件",
    "作品集中的工具界面展示，含竞品信息、主页作品、评论与逐字稿入口",
  ),
  img(
    "15-sound-library",
    "高质量音效素材库",
    "音效文件的分类与整理",
    "landscape",
  ),
  img(
    "16-sound-library-alt",
    "SPL5 音效素材库",
    "按钮、转场、爆炸等声音素材的整理",
    "landscape",
  ),
];
export const feishuCollection: Project = {
  id: "feishu",
  name: "内容创作作品集",
  category: "CONTENT / FEISHU COLLECTION",
  layout: "collection",
  images: [],
  preview: [],
  description:
    "教程作品、内容研究、分镜脚本与制作流程，集中收录于一份内容创作档案。",
  details: [],
};
export const projects: Project[] = [
  {
    id: "content",
    collectionId: "feishu",
    name: "AI 教程与内容作品",
    category: "01 / VIDEO CONTENT",
    layout: "phones",
    preview: [1, 0, 2],
    images: videos,
    description:
      "从 Codex、OpenClaw 到飞书工作流，用具体场景讲清工具的使用与原理。",
    details: [
      {
        title: "把技术话题变成具体任务",
        text: "安装、配置、模型接入和办公工作流，都是能够用步骤和画面说明的内容入口。作品集保留了六条内容的原始截图。",
      },
      {
        title: "看得到内容，也看得到过程",
        text: "Codex 案例还配有文案分镜与视频拆解报告，可在下方的研究与脚本作品中查看。",
      },
    ],
  },
  {
    id: "research",
    collectionId: "feishu",
    name: "内容研究与分镜脚本",
    category: "03 / RESEARCH & SCRIPT",
    layout: "research",
    preview: [1, 2, 3],
    images: research,
    report: true,
    description:
      "从受众和竞品出发，把选题判断、文案结构与画面安排落在具体材料里。",
    details: [
      {
        title: "研究之前，先看材料",
        text: "受众画像、竞品账号对照与选题库，展示内容策划的资料整理；拆解分镜按参考视频原意整理，把文案与画面、动作和约略时间点逐项对应。",
      },
      {
        title: "复盘一条具体的教程",
        text: "《Codex 安装教程》拆解从选题、开头、正文到结尾，同时结合星图记录和评论样本，区分可确认的数据与内容判断。",
      },
    ],
  },
  {
    id: "workflow",
    collectionId: "feishu",
    name: "AI 辅助制作与素材管理",
    category: "04 / WORKFLOW & TOOLS",
    layout: "tools",
    preview: [1, 2, 0],
    images: tools,
    workflow: true,
    description: "把资料采集、素材整理与剪辑流程放在同一条内容生产链中。",
    details: [
      {
        title: "资料采集与素材归档",
        text: "作品集展示了抖音主页视频数据抓取插件的界面，以及两组音效素材库。这里展示工具与整理方式，不将界面功能等同于已完成的采集结果。",
      },
      {
        title: "直播切片流程学习",
        text: "原作品集附有《直播切片 skill · v3 进阶》学习资料。资料中的选段、开头、精剪、包装流程整理如下，归类为学习实践；原资料与默认风格来自喂鱼。",
      },
    ],
  },
  {
    id: "chroma",
    name: "衣序 CHROMA 视频编辑器",
    category: "02 / INTERACTIVE TOOL",
    layout: "app",
    preview: [0],
    images: [
      img(
        "chroma-editor",
        "衣序 CHROMA 编辑界面",
        "已有 MiniMax 穿搭视频的剪辑界面，包含片段选择、播放预览、序列与截取范围。",
        "landscape",
      ),
    ],
    description:
      "已有视频的播放、片段裁剪与导出。免费在线剪辑，自动换装尚未接入。",
    liveUrl: "https://d2539891994-commits.github.io/chroma.html",
    status: "已上线 · 剪辑免费",
    details: [
      {
        title: "直接在浏览器里剪辑",
        text: "围绕已有 MiniMax 穿搭视频选择片段、调整截取范围与顺序，预览播放并导出视频。也可调整播放速度与音量，保存项目后继续编辑。",
      },
      {
        title: "当前版本能做到哪里",
        text: "原视频剪辑免费，项目已公开，可直接在线体验。目前是已有视频编辑器，上传新穿搭自动换装尚未接入。",
      },
    ],
    sourceNote:
      "界面截图来自衣序公开版本。画面中的人物与穿搭来自已有 MiniMax 成片。",
  },
  feishuCollection,
];
export const feishuProjects = projects.filter(
  (project) => project.collectionId === feishuCollection.id,
);
export const showcases = [
  {
    project: feishuCollection,
    label: "CONTENT COLLECTION",
    tags: ["教程作品", "研究与脚本", "制作流程"],
    action: "打开作品集",
  },
  {
    project: projects.find((project) => project.id === "chroma")!,
    label: "INTERACTIVE TOOL",
    tags: ["视频剪辑", "浏览器工具", "在线体验"],
    action: "查看项目",
  },
];
export const workflowSteps = [
  {
    number: "01",
    title: "选段与选题",
    text: "整理直播内容，筛选能独立成立的观点，保留起止时间与核心问题。",
  },
  {
    number: "02",
    title: "开头与发布包",
    text: "确定开头和承接句，让标题、封面文字与正文围绕同一件事。",
  },
  {
    number: "03",
    title: "精剪与校对",
    text: "处理气口、口误和重复，按语义断句，校对字幕与专业词。",
  },
  {
    number: "04",
    title: "包装与检查",
    text: "补充重点字、画面素材和音效，再检查字幕、声音与成片表达。",
  },
];
export const reportMetrics = [
  { value: "9,835,414", label: "累计播放" },
  { value: "440,927", label: "点赞" },
  { value: "432,099", label: "收藏" },
];
