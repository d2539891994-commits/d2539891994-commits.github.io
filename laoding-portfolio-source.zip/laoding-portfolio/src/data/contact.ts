export type ContactChannel = {
  kind: "email" | "wechat" | "link";
  value: string;
  label?: string;
};

// Keep null while contact details are private; the dialog shows its pending state.
export const contact: ContactChannel | null = null;
