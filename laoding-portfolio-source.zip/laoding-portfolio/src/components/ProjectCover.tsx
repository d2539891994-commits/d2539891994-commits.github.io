import {
  ArrowUpRight,
  Braces,
  FileText,
  FolderOpen,
  Scissors,
  Volume2,
} from "lucide-react";
import type { Project } from "../data/content";
import type { CSSProperties } from "react";

/** Editorial framing uses the original screenshots; full sources stay in the gallery. */
export function ProjectCover({
  project,
  compact = false,
  shared = true,
}: {
  project: Project;
  compact?: boolean;
  shared?: boolean;
}) {
  return (
    <div
      style={{ viewTransitionName: shared ? `cover-${project.id}` : "none" } as CSSProperties}
      className={`editorial-cover cover-${project.id}${compact ? " cover-compact" : ""}`}
    >
      {project.id === "feishu" ? (
        <>
          <span className="cover-index"><FolderOpen size={13} /> CONTENT ARCHIVE</span>
          <div className="collection-cover-copy">
            <strong>内容创作<br />作品集<span>。</span></strong>
            <p>从想法，到作品。</p>
            <div className="collection-cover-topics">
              <span>教程内容</span>
              <span>研究与脚本</span>
              <span>制作与工作流</span>
            </div>
          </div>
          <div className="collection-paper collection-paper-back">
            <span><FileText size={11} /> RESEARCH / SCRIPT</span>
            <img
              src="/images/portfolio/14-storyboard.webp"
              alt="作品集中的分镜脚本材料局部"
              loading="lazy"
            />
          </div>
          <div className="collection-paper collection-paper-front">
            <span><FileText size={11} /> VIDEO / CONTENT</span>
            <div className="source-crop">
              <img
                src="/images/portfolio/12-codex-deepseek.webp"
                alt="作品集中的 Codex 教程画面局部"
                loading="lazy"
              />
            </div>
            <span className="collection-paper-foot">小丁 · 内容创作档案 <ArrowUpRight size={12} /></span>
          </div>
          <span className="cover-source">飞书作品集 / 教程 · 研究 · 制作</span>
        </>
      ) : project.id === "content" ? (
        <>
          <div className="cover-grid" aria-hidden="true" />
          <span className="cover-index">AI CONTENT / FIELD NOTES</span>
          <div className="content-cover-copy">
            <span>
              <Braces size={20} /> TOOLS, EXPLAINED.
            </span>
            <strong>
              从安装
              <br />
              到上手<span>。</span>
            </strong>
            <p>让工具的使用，有迹可循。</p>
          </div>
          <div className="tutorial-window tutorial-back">
            <div className="cover-window-bar">
              <span className="window-dots">
                <i />
                <i />
                <i />
              </span>
              <span>OPENCLAW / TUTORIAL</span>
            </div>
            <div className="source-crop">
              <img
                src="/images/portfolio/09-openclaw.webp"
                alt="OpenClaw 教程原始作品截图局部"
                loading="lazy"
              />
            </div>
          </div>
          <div className="tutorial-window tutorial-front">
            <div className="cover-window-bar">
              <span className="window-dots">
                <i />
                <i />
                <i />
              </span>
              <span>CODEX + DEEPSEEK</span>
            </div>
            <div className="source-crop">
              <img
                src="/images/portfolio/12-codex-deepseek.webp"
                alt="Codex 与 DeepSeek 教程原始作品截图局部"
                loading="lazy"
              />
            </div>
            <div className="tutorial-chapters">
              <span>安装</span>
              <i />
              <span>接入</span>
              <i />
              <span>使用</span>
            </div>
          </div>
          <span className="cover-source">原作品截图 · 局部展示</span>
        </>
      ) : project.id === "chroma" ? (
        <>
          <span className="cover-index">BROWSER-BASED VIDEO EDITOR</span>
          <div className="chroma-cover-copy">
            <span>
              <Scissors size={18} /> 衣序
            </span>
            <strong>
              CHROMA<span>✳</span>
            </strong>
            <p>把片段，剪成自己的节奏。</p>
          </div>
          <div className="chroma-window">
            <div className="cover-window-bar">
              <span className="window-dots">
                <i />
                <i />
                <i />
              </span>
              <span>CHROMA / WORKSPACE</span>
              <ArrowUpRight size={12} />
            </div>
            <img
              src="/images/portfolio/chroma-editor.webp"
              alt="衣序 CHROMA 公开版本的真实编辑界面"
              loading="lazy"
              width="1710"
              height="865"
            />
          </div>
          <div className="cover-timeline" aria-hidden="true">
            <Scissors size={13} />
            <span />
            <span />
            <span />
            <span />
            <i />
          </div>
          <span className="cover-source">真实界面 / 已有视频剪辑</span>
        </>
      ) : project.id === "research" ? (
        <>
          <span className="cover-index">RESEARCH / STORYBOARD</span>
          <div className="research-cover-copy">
            <FileText size={23} />
            <strong>
              每一个画面，
              <br />
              都有来处。
            </strong>
            <span>受众 · 选题 · 拆解分镜</span>
          </div>
          <div className="research-paper">
            <span>CODEX / 拆解分镜</span>
            <img
              src="/images/portfolio/14-storyboard.webp"
              alt="Codex 参考视频拆解分镜表局部"
              loading="lazy"
            />
          </div>
          <span className="cover-source">参考视频拆解材料</span>
        </>
      ) : (
        <>
          <span className="cover-index">WORKFLOW / SOUND & TOOLS</span>
          <div className="workflow-cover-copy">
            <Volume2 size={25} />
            <strong>
              让创作，
              <br />
              有序发生。
            </strong>
            <span>资料采集 / 素材归档 / 流程学习</span>
          </div>
          <div className="sound-sleeve">
            <span>
              SOUND
              <br />
              LIBRARY<span>素材管理</span>
            </span>
            <div className="sound-wave" aria-hidden="true">
              {Array.from({ length: 23 }, (_, i) => (
                <i
                  key={i}
                  style={{ height: `${18 + ((i * 17 + 11) % 65)}%` }}
                />
              ))}
            </div>
            <img
              src="/images/portfolio/15-sound-library.webp"
              alt="音效素材库真实目录界面"
              loading="lazy"
            />
          </div>
          <span className="cover-source">工具记录与学习实践</span>
        </>
      )}
    </div>
  );
}
