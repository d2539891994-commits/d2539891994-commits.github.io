import type { ReactNode } from "react";
import type { Project } from "../data/content";
import { projectPath } from "../lib/navigation";

export function ProjectLink({
  project,
  onOpen,
  className,
  label,
  children,
}: {
  project: Project;
  onOpen: (project: Project) => void;
  className?: string;
  label?: string;
  children: ReactNode;
}) {
  return (
    <a
      href={projectPath(project)}
      className={className}
      aria-label={label}
      onClick={(event) => {
        if (
          event.button !== 0 ||
          event.metaKey ||
          event.ctrlKey ||
          event.shiftKey ||
          event.altKey
        )
          return;
        event.preventDefault();
        onOpen(project);
      }}
    >
      {children}
    </a>
  );
}
