import { motion, useReducedMotion } from "framer-motion";
import type { CSSProperties, ReactNode } from "react";

const elements = {
  div: motion.create("div"),
  header: motion.create("header"),
  section: motion.create("section"),
};

interface FadeInProps {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  as?: keyof typeof elements;
  delay?: number;
  duration?: number;
  x?: number;
  y?: number;
}

export function FadeIn({
  children,
  className,
  style,
  as = "div",
  delay = 0,
  duration = 0.55,
  x = 0,
  y = 20,
}: FadeInProps) {
  const reduce = useReducedMotion();
  const Element = elements[as];
  return (
    <Element
      className={className}
      style={style}
      initial={{ opacity: 0, x: reduce ? 0 : x, y: reduce ? 0 : y }}
      whileInView={{ opacity: 1, x: 0, y: 0 }}
      viewport={{ once: true, margin: "50px", amount: 0 }}
      transition={{
        duration: reduce ? 0.15 : duration,
        delay: reduce ? 0 : delay,
        ease: [0.25, 0.1, 0.25, 1],
      }}
    >
      {children}
    </Element>
  );
}
