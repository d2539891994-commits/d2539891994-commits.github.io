import { useEffect, useRef, type PointerEvent } from "react";
import { motion, useMotionValue, useReducedMotion, useSpring } from "framer-motion";

export function PortraitCard() {
  const surface = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const targetX = useMotionValue(0);
  const targetY = useMotionValue(0);
  const rotateX = useSpring(targetX, { stiffness: 170, damping: 25, mass: 0.8 });
  const rotateY = useSpring(targetY, { stiffness: 170, damping: 25, mass: 0.8 });
  const reset = () => { targetX.set(0); targetY.set(0); };

  useEffect(() => {
    const clear = () => { targetX.set(0); targetY.set(0); };
    if (reduce) clear();
    window.addEventListener("blur", clear);
    window.addEventListener("scroll", clear, { passive: true });
    return () => {
      window.removeEventListener("blur", clear);
      window.removeEventListener("scroll", clear);
    };
  }, [reduce, targetX, targetY]);

  const follow = (event: PointerEvent<HTMLDivElement>) => {
    if (reduce || event.pointerType !== "mouse"
      || !window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
    const bounds = surface.current?.getBoundingClientRect();
    if (!bounds) return;
    // Measure the stationary wrapper so the rotating card never feeds back into its own angle.
    const x = Math.max(-1, Math.min(1, (event.clientX - bounds.left) / bounds.width * 2 - 1));
    const y = Math.max(-1, Math.min(1, (event.clientY - bounds.top) / bounds.height * 2 - 1));
    targetX.set(-y * 7);
    targetY.set(x * 9);
  };

  return (
    <div
      ref={surface}
      className="portrait-perspective"
      onPointerMove={follow}
      onPointerLeave={reset}
      onPointerCancel={reset}
    >
      <motion.figure
        className="about-portrait"
        style={reduce ? undefined : { rotateX, rotateY }}
      >
        <div className="about-portrait-image">
          <img
            src="/images/laoding-portrait.webp"
            alt="LaoDing 身穿黑色毛衣的个人形象照"
            width="1086"
            height="1448"
            loading="lazy"
            decoding="async"
          />
        </div>
        <figcaption>
          <span>LaoDing<span aria-hidden="true">✳</span></span>
          <span>IP 编导 / IP 运营</span>
        </figcaption>
      </motion.figure>
    </div>
  );
}
