import { useEffect, useState } from "react";
import { Check, Copy } from "lucide-react";
import type { Project } from "../data/content";
import { projectPath } from "../lib/navigation";

export function CaseShare({ project }: { project: Project }) {
  const [message, setMessage] = useState("");
  useEffect(() => {
    if (!message) return;
    const timer = window.setTimeout(() => setMessage(""), 2500);
    return () => window.clearTimeout(timer);
  }, [message]);
  return (
    <button
      className="case-share"
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(
            new URL(projectPath(project), window.location.origin).href,
          );
          setMessage("链接已复制");
        } catch {
          setMessage("请复制地址栏链接");
        }
      }}
    >
      {message === "链接已复制" ? <Check size={14} /> : <Copy size={14} />}
      <span aria-live="polite">{message || (project.layout === "collection" ? "分享作品集" : "分享案例")}</span>
    </button>
  );
}
