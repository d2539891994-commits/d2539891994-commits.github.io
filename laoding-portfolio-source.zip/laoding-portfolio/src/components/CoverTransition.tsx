import { motion } from "framer-motion";
import { ProjectCover } from "./ProjectCover";
import type { CoverFlight } from "../lib/navigation";

export function CoverTransition({
  flight,
  onComplete,
}: {
  flight: CoverFlight;
  onComplete: () => void;
}) {
  return (
    <motion.div
      aria-hidden="true"
      className="cover-flight"
      initial={flight.from}
      animate={flight.to}
      transition={{ duration: 0.62, ease: [0.22, 0.7, 0.2, 1] }}
      onAnimationComplete={onComplete}
    >
      <motion.div
        className={`flight-cover-layer ${flight.toCase ? "" : "case-cover-wrap"}`}
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
      >
        <ProjectCover project={flight.project} />
      </motion.div>
      <motion.div
        className={`flight-cover-layer ${flight.toCase ? "case-cover-wrap" : ""}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, delay: 0.15 }}
      >
        <ProjectCover project={flight.project} />
      </motion.div>
    </motion.div>
  );
}
