import { useRef, useState } from "react";
import { ArrowUpRight, Play } from "lucide-react";

export function CaseMedia() {
  const ref = useRef<HTMLVideoElement>(null);
  const [started, setStarted] = useState(false);
  const seekTo = useRef(0);
  const playAt = (time: number) => {
    const video = ref.current;
    if (!video) return;
    seekTo.current = time;
    if (video.readyState >= 1) video.currentTime = time;
    void video.play().catch(() => setStarted(false));
  };
  return (
    <div className="case-demo">
      <div className="demo-toolbar">
        <span className="status-dot" /> CHROMA / ACTUAL WORKSPACE
        <span>真实操作节选 · 无声</span>
      </div>
      <div className="demo-screen">
        <video
          ref={ref}
          controls
          playsInline
          preload="none"
          poster="/media/chroma-demo-poster.webp"
          aria-label="CHROMA 实际操作演示：选择片段、播放、调整裁剪范围和查看导出设置"
          onPlay={() => setStarted(true)}
          onLoadedMetadata={() => {
            if (ref.current) ref.current.currentTime = seekTo.current;
          }}
        >
          <source src="/media/chroma-demo.mp4" type="video/mp4" />
          <track
            src="/media/chroma-demo.zh.vtt"
            kind="captions"
            srcLang="zh"
            label="中文说明"
            default
          />
          当前浏览器无法播放，请打开在线编辑器体验。
        </video>
        {!started && (
          <button type="button" className="demo-play" onClick={() => playAt(0)}>
            <Play size={19} fill="currentColor" />
            <span>播放操作演示</span>
          </button>
        )}
      </div>
      <div className="demo-chapters">
        {[
          { t: 0, n: "01", label: "选择与预览" },
          { t: 4.34, n: "02", label: "裁剪范围" },
          { t: 7.382, n: "03", label: "导出设置" },
        ].map((step) => (
          <button type="button" key={step.n} onClick={() => playAt(step.t)}>
            <span>{step.n}</span>
            {step.label}
            <ArrowUpRight size={13} />
          </button>
        ))}
      </div>
      <p className="demo-note">
        录自公开编辑器，等候时间已压缩。人物与穿搭来自已有 MiniMax 成片。
      </p>
    </div>
  );
}
