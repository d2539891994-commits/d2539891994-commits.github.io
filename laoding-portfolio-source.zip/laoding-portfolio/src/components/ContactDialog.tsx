import { useState } from "react";
import { ArrowUpRight, Check, Copy, Mail, MessageCircle } from "lucide-react";
import { Dialog } from "./Dialog";
import { contact } from "../data/contact";

export function ContactDialog({ onClose }: { onClose: () => void }) {
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  const copyContact = async () => {
    if (!contact) return;
    try {
      await navigator.clipboard.writeText(contact.value);
      setCopied(true);
      setCopyError(false);
    } catch {
      setCopied(false);
      setCopyError(true);
    }
  };
  const emailUrl = contact?.kind === "email"
    ? `mailto:${contact.value}?subject=${encodeURIComponent("与 LaoDing 交流合作")}`
    : undefined;

  return (
    <Dialog onClose={onClose} titleId="contact-title" className="contact-dialog">
      <span className="eyebrow">CONTACT / LAODING</span>
      <h2 id="contact-title">让想法，<br /><span>发生。</span></h2>
      <p className="dialog-intro">内容策划、AI 应用与交互工具，欢迎交流与合作。</p>
      {contact ? (
        <div className="contact-channel">
          <span className="contact-channel-label">
            {contact.kind === "email" ? <Mail size={16} /> : <MessageCircle size={16} />}
            {contact.label ?? (contact.kind === "email" ? "电子邮箱" : contact.kind === "wechat" ? "微信" : "联系页面")}
          </span>
          <p className="contact-value">{contact.value}</p>
          <div className="contact-actions">
            {emailUrl && <a href={emailUrl} className="reference-cta">发送邮件 <ArrowUpRight size={17} /></a>}
            {contact.kind === "link" && <a href={contact.value} className="reference-cta" target="_blank" rel="noopener noreferrer">前往联系页面 <ArrowUpRight size={17} /></a>}
            <button type="button" onClick={copyContact} className={contact.kind === "wechat" ? "reference-cta" : "contact-copy"}>
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? "已复制" : contact.kind === "wechat" ? "复制微信号" : "复制"}
            </button>
          </div>
          <p role="status" className="contact-status">
            {copyError ? "请选中上方联系方式，手动复制。" : copied ? "已复制到剪贴板。" : ""}
          </p>
        </div>
      ) : <p className="contact-pending">联系方式稍后公开。</p>}
    </Dialog>
  );
}
