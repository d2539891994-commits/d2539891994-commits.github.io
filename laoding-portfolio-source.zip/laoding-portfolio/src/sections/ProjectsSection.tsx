import { ArrowUpRight } from "lucide-react";
import { useRef, type CSSProperties } from "react";
import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { showcases, type Project } from "../data/content";
import { FadeIn } from "../components/FadeIn";
import { ProjectCover } from "../components/ProjectCover";
import { ProjectLink } from "../components/ProjectLink";

function StackedProject({
  showcase: { project, label, tags, action }, index, total, progress, onProject,
}: {
  showcase: (typeof showcases)[number];
  index: number;
  total: number;
  progress: MotionValue<number>;
  onProject: (project: Project) => void;
}) {
  const reduce = useReducedMotion();
  const scale = useTransform(progress, [index / total, (index + 1) / total],
    [1, 1 - (total - 1 - index) * 0.035]);
  return (
    <div className="showcase-slot" style={{ "--card-index": index, zIndex: index + 1 } as CSSProperties}>
      <motion.article className={`showcase-card showcase-${project.id}`} style={reduce ? undefined : { scale }}>
        <ProjectLink project={project} onOpen={onProject} className="cover-open" label={`打开${project.name}`}>
          <ProjectCover project={project} />
          <span className="cover-open-arrow"><ArrowUpRight size={21} /></span>
        </ProjectLink>
        <div className="showcase-copy">
          <span className="small-label">0{index + 1} / {label}</span>
          <h3><ProjectLink project={project} onOpen={onProject}>
            {project.id === "chroma" ? <>衣序 CHROMA<br />视频编辑器</> : project.name}
          </ProjectLink></h3>
          <p>{project.description}</p>
          <div className="case-tags">{tags.map(tag => <span key={tag}>{tag}</span>)}</div>
          <div className="showcase-actions">
            <ProjectLink project={project} onOpen={onProject} className="text-link">
              {action} <ArrowUpRight size={16} />
            </ProjectLink>
            {project.liveUrl && <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="text-link showcase-live">
              在线体验 <ArrowUpRight size={15} />
            </a>}
          </div>
        </div>
      </motion.article>
    </div>
  );
}

export function ProjectsSection({
  onProject,
}: {
  onProject: (project: Project) => void;
}) {
  const stack = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: stack, offset: ["start start", "end end"] });
  return (
    <section
      id="projects"
      className="selected-section page-gutter"
      aria-labelledby="projects-title"
    >
      <FadeIn>
        <div className="section-heading-row">
          <div>
            <span className="studio-eyebrow">01 / SELECTED PROJECTS</span>
            <h2 id="projects-title" tabIndex={-1}>
              作品与项目<span>。</span>
            </h2>
          </div>
          <p>内容、工具，以及不断发生的探索。</p>
        </div>
      </FadeIn>
      <div className="showcase-stack" ref={stack}>
        {showcases.map((showcase, index) => (
          <StackedProject key={showcase.project.id} showcase={showcase} index={index}
            total={showcases.length} progress={scrollYProgress} onProject={onProject} />
        ))}
      </div>
    </section>
  );
}
