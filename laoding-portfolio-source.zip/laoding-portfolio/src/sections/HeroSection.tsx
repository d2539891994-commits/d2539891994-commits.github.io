import { useRef, type PointerEvent, type KeyboardEvent } from "react";
import {
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
  useTransform,
} from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { FadeIn } from "../components/FadeIn";
import { projects } from "../data/content";

const strengths = [
  "聚焦 AI 应用与商业认知类 IP，具备选题策划、脚本构建与后期制作能力。",
  "擅长从用户需求与理解门槛出发，提炼内容切口、组织叙事结构，将专业知识转化为兼具信息价值与观看节奏的短视频内容。",
];
const clamp = (value: number, limit: number) => Math.max(-limit, Math.min(limit, value));

export function HeroSection({ onContact }: { onContact: () => void }) {
  const portrait = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const reduce = useReducedMotion();
  const targetX = useMotionValue(0);
  const targetY = useMotionValue(0);
  const x = useSpring(targetX, { stiffness: 115, damping: 22, mass: 0.8 });
  const y = useSpring(targetY, { stiffness: 115, damping: 22, mass: 0.8 });
  const rotateY = useTransform(x, [-45, 45], [-5, 5]);
  const rotateX = useTransform(y, [-30, 30], [4, -4]);
  const reset = () => { targetX.set(0); targetY.set(0); };
  const follow = (event: PointerEvent<HTMLElement>) => {
    if (reduce || dragging.current || event.pointerType !== "mouse") return;
    const bounds = portrait.current?.getBoundingClientRect();
    if (!bounds) return;
    const padding = 150;
    const nearby = event.clientX >= bounds.left - padding && event.clientX <= bounds.right + padding
      && event.clientY >= bounds.top - padding && event.clientY <= bounds.bottom + padding;
    if (!nearby) { reset(); return; }
    targetX.set(clamp((event.clientX - bounds.left - bounds.width / 2) / 3, 45));
    targetY.set(clamp((event.clientY - bounds.top - bounds.height / 2) / 3, 30));
  };
  const keyboardMove = (event: KeyboardEvent<HTMLDivElement>) => {
    if (reduce) return;
    if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
      event.preventDefault();
      targetX.set(event.key === "ArrowLeft" ? -35 : 35);
    }
    if (event.key === "Escape") reset();
  };
  const toolUrl = projects.find((project) => project.id === "chroma")?.liveUrl;
  return (
    <section
      className="reference-hero"
      aria-labelledby="hero-title"
      onPointerMove={follow}
      onPointerLeave={reset}
    >
      <FadeIn as="header" className="reference-nav" y={-20}>
        <nav aria-label="主导航">
          <a href="#about" aria-label="关于我">ABOUT</a>
          <a href="#strengths" aria-label="核心优势">STRENGTHS</a>
          <a href="#projects" aria-label="作品与项目">PROJECTS</a>
          <a href={toolUrl} target="_blank" rel="noopener noreferrer" aria-label="在线工具 CHROMA">TOOLS <ArrowUpRight size={15} /></a>
        </nav>
      </FadeIn>
      <FadeIn className="reference-heading-wrap" delay={0.15} y={35}>
        <h1 id="hero-title">HI, I&apos;M LAODING</h1>
      </FadeIn>
      <div className="reference-portrait-stage" ref={portrait}>
        <FadeIn className="reference-avatar-entry" delay={0.5} y={25} duration={0.8}>
          <motion.div
            className="reference-avatar-motion"
            style={reduce ? undefined : { x, y, rotateX, rotateY }}
          >
            <motion.div
              className="reference-avatar-grab"
              drag={reduce ? false : "x"}
              dragConstraints={{ left: -55, right: 55 }}
              dragElastic={0.12}
              dragMomentum={false}
              dragSnapToOrigin
              onDragStart={() => { dragging.current = true; reset(); }}
              onDragEnd={() => { dragging.current = false; reset(); }}
              tabIndex={reduce ? undefined : 0}
              role="img"
              aria-label="LaoDing 的全身人物形象，可左右拖动"
              onKeyDown={keyboardMove}
              onKeyUp={reset}
              onBlur={reset}
            >
              <img
                src="/images/laoding-full-body.webp"
                alt=""
                aria-hidden="true"
                width="1024"
                height="1536"
                draggable={false}
                fetchPriority="high"
              />
            </motion.div>
          </motion.div>
        </FadeIn>
      </div>
      <div className="reference-bottom-bar">
        <FadeIn className="reference-strengths" delay={0.35} y={20}>
          <div id="strengths">
            <span className="reference-strengths-label">核心优势 / CORE STRENGTHS</span>
            {strengths.map((text) => <p key={text}>{text}</p>)}
          </div>
        </FadeIn>
        <FadeIn className="reference-action" delay={0.5} y={20}>
          <button className="reference-cta" type="button" onClick={onContact}>
            CONTACT ME <ArrowUpRight size={18} />
          </button>
        </FadeIn>
      </div>
      <span className="reference-interaction-hint" aria-hidden="true">移动鼠标 · 轻拖人物</span>
    </section>
  );
}
