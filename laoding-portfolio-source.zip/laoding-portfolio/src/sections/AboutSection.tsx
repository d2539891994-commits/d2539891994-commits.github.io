import { ArrowUp, ArrowUpRight, Download } from "lucide-react";
import { FadeIn } from "../components/FadeIn";
import { PortraitCard } from "../components/PortraitCard";

export function AboutSection({ onContact }: { onContact: () => void }) {
  return (
    <>
      <section
        id="about"
        className="studio-about page-gutter"
        aria-labelledby="about-title"
      >
        <FadeIn>
          <PortraitCard />
        </FadeIn>
        <FadeIn delay={0.08}>
          <div className="about-editorial">
            <span className="studio-eyebrow">02 / A LITTLE ABOUT ME</span>
            <h2 id="about-title">
              你好，我是 LaoDing。
              <br />
              <span>关注工具，更关注表达。</span>
            </h2>
            <p>
              我关注 AI 应用与知识类内容，喜欢把复杂的工具和概念讲清楚，也喜欢把想法做成可以观看、阅读和使用的作品。这里记录我的内容创作、交互工具，以及持续探索中的个人实践。
            </p>
            <div className="about-contact-actions">
              <button className="reference-cta" type="button" onClick={onContact}>
                CONTACT ME <ArrowUpRight size={16} />
              </button>
              <a className="text-link" href="#projects">浏览作品与项目 <ArrowUpRight size={16} /></a>
            </div>
          </div>
        </FadeIn>
      </section>
      <footer className="studio-footer page-gutter">
        <a href="#top" className="wordmark">
          LaoDing<span>✳</span>
        </a>
        <span>© {new Date().getFullYear()} LaoDing · 作品、工具与个人探索</span>
        {import.meta.env.VITE_STANDALONE_HTML !== "true" && (
          <nav className="site-downloads" aria-label="开源与下载">
            <a className="text-link" href="/downloads/laoding-portfolio-source.zip" download>
              开源代码 · MIT <Download size={14} />
            </a>
            <a className="text-link" href="/downloads/laoding-portfolio-html.zip" download>
              下载 HTML <Download size={14} />
            </a>
          </nav>
        )}
        <a className="text-link" href="#top">
          回到顶部 <ArrowUp size={14} />
        </a>
      </footer>
    </>
  );
}
