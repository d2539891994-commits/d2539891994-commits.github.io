import { useEffect, useRef, useState } from "react";
import { motion, useScroll } from "framer-motion";
import { ArrowLeft, ArrowUpRight, FileText, Maximize2 } from "lucide-react";
import {
  projects,
  feishuCollection,
  reportMetrics,
  siteConfig,
  workflowSteps,
  type PortfolioImage,
  type Project,
} from "../data/content";
import { ProjectCover } from "../components/ProjectCover";
import { CaseShare } from "../components/CaseShare";
import { CaseMedia } from "../components/CaseMedia";
import { ProjectLink } from "../components/ProjectLink";
import { FadeIn } from "../components/FadeIn";

export function Gallery({
  project,
  onImage,
}: {
  project: Project;
  onImage: (image: PortfolioImage) => void;
}) {
  return (
    <div className={`portfolio-gallery gallery-${project.layout}`}>
      {project.images.map((item) => (
        <figure
          key={item.src}
          className={`portfolio-figure figure-${item.shape}`}
        >
          <button
            className="gallery-image-button"
            type="button"
            onClick={() => onImage(item)}
            aria-label={`放大查看${item.title}`}
          >
            <img
              src={item.src}
              alt={item.caption}
              loading="lazy"
              decoding="async"
            />
            <span>
              <Maximize2 size={15} /> 查看原图
            </span>
          </button>
          <figcaption>
            <strong>{item.title}</strong>
            <span>{item.caption}</span>
          </figcaption>
        </figure>
      ))}
    </div>
  );
}

export function Evidence({ onRead }: { onRead: () => void }) {
  return (
    <div className="case-evidence">
      <div>
        <span className="studio-eyebrow">SOURCE / 2026.10.20</span>
        <h3>作品表现，有明确的口径。</h3>
        <p>
          下列数据来自原报告的星图记录，属于林粒粒呀账号的对应作品，不等同于个人独立贡献。
        </p>
      </div>
      <div className="report-metrics">
        {reportMetrics.map((metric) => (
          <div key={metric.label}>
            <strong>{metric.value}</strong>
            <span>{metric.label}</span>
          </div>
        ))}
      </div>
      <div className="evidence-footer">
        <p>
          采集时间：2026年10月20日11:44。评论样本为39条去重主评文本（n=39）；不据此推算完整受众或转化结果。
        </p>
        <button
          className="studio-button light-button"
          type="button"
          onClick={onRead}
        >
          <FileText size={15} /> 阅读完整拆解
        </button>
      </div>
    </div>
  );
}

export function WorkflowNotes() {
  return (
    <div className="workflow-steps">
      {workflowSteps.map((step) => (
        <div key={step.number}>
          <span>{step.number}</span>
          <div><h4>{step.title}</h4><p>{step.text}</p></div>
        </div>
      ))}
      <p className="evidence-note">
        流程整理自「直播切片 skill · v3 进阶」学习资料，原资料与默认风格来自喂鱼。这里展示学习过程，不提供第三方素材包下载。
      </p>
    </div>
  );
}

export function CasePage({
  project,
  onBack,
  onProject,
  onImage,
  onRead,
}: {
  project: Project;
  onBack: () => void;
  onProject: (project: Project) => void;
  onImage: (image: PortfolioImage) => void;
  onRead: () => void;
}) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });
  const [chapter, setChapter] = useState("overview");
  const isContent = project.id === "content";
  const isChroma = project.id === "chroma";
  const parent = projects.find((item) => item.id === project.collectionId);
  const goBack = parent ? () => onProject(parent) : onBack;
  const backLabel = parent ? "返回内容作品集" : "返回个人首页";
  const next = isChroma
    ? feishuCollection
    : isContent
      ? projects[1]
      : project.id === "research"
        ? projects[2]
        : feishuCollection;
  const chapters = [
    { id: "overview", label: "项目概览" },
    { id: "approach", label: isChroma ? "操作体验" : "内容思路" },
    { id: "materials", label: isChroma ? "界面记录" : "原始材料" },
  ];
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setChapter(visible[0].target.id.replace("case-", ""));
      },
      { rootMargin: "-15% 0px -55% 0px", threshold: 0 },
    );
    ref.current
      ?.querySelectorAll("[data-case-chapter]")
      .forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [project.id]);
  const jump = (id: string) => {
    setChapter(id);
    document.getElementById(`case-${id}`)?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "instant"
        : "smooth",
      block: "start",
    });
  };
  return (
    <main ref={ref} className={`case-page case-page-${project.id}`}>
      <header className="case-nav page-gutter">
        <button type="button" className="case-back" onClick={goBack}>
          <ArrowLeft size={16} />
          <span>{backLabel}</span>
        </button>
        <span className="case-nav-name">
          LaoDing <span>/</span> {isChroma ? "CHROMA" : "CASE STUDY"}
        </span>
        <CaseShare project={project} />
        <motion.span
          className="case-reading-progress"
          style={{ scaleX: scrollYProgress }}
        />
      </header>
      <div className="case-page-head page-gutter">
        <span className="studio-eyebrow">{project.category}</span>
        <h1 id="case-title" tabIndex={-1}>
          {isChroma ? (
            <>
              <span>衣序 CHROMA</span>
              <span className="case-title-kind">视频编辑器</span>
            </>
          ) : (
            project.name
          )}
        </h1>
        <div className="case-head-bottom">
          <p>
            {isContent
              ? "从工具的使用开始，关注观众如何看懂、如何跟做。"
              : isChroma
                ? "把已有视频，剪成自己的节奏。"
                : project.description}
          </p>
          {project.liveUrl && (
            <a
              href={project.liveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="studio-button primary-button"
            >
              在线体验 <ArrowUpRight size={16} />
            </a>
          )}
        </div>
      </div>
      <div className="case-cover-wrap page-gutter">
        <ProjectCover project={project} />
      </div>
      <div className="case-page-body page-gutter" id="case-body">
        <aside className="case-chapter-nav" aria-label="案例章节">
          {chapters.map((item, i) => (
            <button
              key={item.id}
              type="button"
              aria-current={chapter === item.id ? "location" : undefined}
              onClick={() => jump(item.id)}
            >
              <span>0{i + 1}</span>
              {item.label}
            </button>
          ))}
          <button type="button" onClick={goBack} className="chapter-return">
            <ArrowLeft size={12} /> {backLabel}
          </button>
        </aside>
        <div className="case-narrative">
          <section id="case-overview" data-case-chapter>
            <span className="studio-eyebrow">01 / THE CONTEXT</span>
            <h2>
              {isContent ? (
                <>
                  安装教程，也需要
                  <br />
                  一条清楚的表达路径。
                </>
              ) : isChroma ? (
                <>
                  已有的视频，
                  <br />
                  也能重新组织。
                </>
              ) : (
                project.details[0].title
              )}
            </h2>
            <p className="case-lead">
              {isContent
                ? "工具区别、环境安装、模型接入，每一步都可能成为新手的疑问。这里把教程作品与参考视频拆解放在一起，展示内容如何从一个问题展开。"
                : isChroma
                  ? "从一条已有的 MiniMax 穿搭成片出发，选择片段、调整范围和顺序，再预览与导出。编辑过程保留原始画幅、人物、服装与色卡。"
                  : project.details[0].text}
            </p>
            <dl className="case-facts">
              <div>
                <dt>内容方向</dt>
                <dd>
                  {isContent
                    ? "AI 应用 / 知识教程"
                    : isChroma
                      ? "浏览器视频编辑"
                      : project.name}
                </dd>
              </div>
              <div>
                <dt>展示材料</dt>
                <dd>
                  {isContent
                    ? "6 条作品截图、拆解分镜与报告"
                    : isChroma
                      ? "真实界面、操作节选与在线工具"
                      : "原作品集中的记录与学习材料"}
                </dd>
              </div>
              <div>
                <dt>材料口径</dt>
                <dd>
                  {isContent
                    ? "账号作品记录与参考视频拆解分别说明"
                    : isChroma
                      ? "剪辑免费 · 自动换装未接入"
                      : "保留原始出处与使用范围"}
                </dd>
              </div>
            </dl>
          </section>
          <section id="case-approach" data-case-chapter>
            <span className="studio-eyebrow">
              02 / {isChroma ? "TRY THE WORKFLOW" : "BEHIND THE WORK"}
            </span>
            <h2>
              {isContent
                ? "先解释，再演示。"
                : isChroma
                  ? "从片段到预览，亲眼看看。"
                  : "判断，落在具体材料里。"}
            </h2>
            {isContent ? (
              <>
                <p className="case-lead">
                  从参考视频中观察表达顺序：先建立工具认知，再进入可跟做的步骤。分镜拆解将文案、画面动作和约略时间点逐项对应。
                </p>
                <div className="case-story-steps">
                  {[
                    {
                      n: "01",
                      title: "把问题说清楚",
                      copy: "从 Codex 与模型的区别入手，为后面的安装和接入建立理解。",
                      image: project.images[0],
                      crop: true,
                    },
                    {
                      n: "02",
                      title: "让操作有画面",
                      copy: "具体工具对应具体使用场景，以安装、配置与接入的画面承接解释。",
                      image: project.images[2],
                      crop: true,
                    },
                    {
                      n: "03",
                      title: "让文字与画面对齐",
                      copy: "按参考视频原意拆分文案与画面动作，约略记录时间点，作为内容拆解材料呈现。",
                      image: projects[1].images[3],
                      crop: false,
                    },
                  ].map((step) => (
                    <FadeIn key={step.n}>
                      <article className="case-story-step">
                        <div>
                          <span>{step.n}</span>
                          <h3>{step.title}</h3>
                          <p>{step.copy}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => onImage(step.image)}
                          className={
                            step.crop
                              ? "source-crop story-source"
                              : "story-table"
                          }
                          aria-label={`查看${step.image.title}原图`}
                        >
                          <img
                            src={step.image.src}
                            alt={step.image.caption}
                            loading="lazy"
                          />
                          <span className="story-source-hint">
                            原始材料 <Maximize2 size={13} />
                          </span>
                        </button>
                      </article>
                    </FadeIn>
                  ))}
                </div>
                <Evidence onRead={onRead} />
              </>
            ) : isChroma ? (
              <>
                <p className="case-lead">
                  以下画面录自实际公开编辑器，展示选取片段、播放、调整入点与出点，以及打开导出设置。可以按章节重看，也可以直接进入工具体验。
                </p>
                <CaseMedia />
                <div className="case-capabilities">
                  {[
                    {
                      n: "01",
                      title: "选择片段",
                      copy: "从原视频中的四套穿搭开始，预览各自对应的片段。",
                    },
                    {
                      n: "02",
                      title: "调整节奏",
                      copy: "设置片段范围与顺序，也可调整播放速度和音量。",
                    },
                    {
                      n: "03",
                      title: "预览与导出",
                      copy: "播放完整序列，查看画幅和时长，再通过导出入口生成剪辑。",
                    },
                  ].map((step) => (
                    <div key={step.n}>
                      <span>{step.n}</span>
                      <h3>{step.title}</h3>
                      <p>{step.copy}</p>
                    </div>
                  ))}
                </div>
                <div className="case-scope">
                  <span>当前版本</span>
                  <p>
                    支持已有视频编辑，剪辑免费。上传新穿搭自动换装尚未接入；人物、服装和色卡来自已有
                    MiniMax 成片。
                  </p>
                </div>
              </>
            ) : (
              <>
                <p className="case-lead">{project.details[1].text}</p>
                {project.report && <Evidence onRead={onRead} />}
                {project.workflow && <WorkflowNotes />}
              </>
            )}
          </section>
          <section id="case-materials" data-case-chapter>
            <span className="studio-eyebrow">03 / SOURCE MATERIAL</span>
            <h2>{isChroma ? "真实界面，完整保留。" : "回到原始材料。"}</h2>
            <p className="case-lead">
              {isChroma
                ? "查看完整编辑界面，或进入公开版本实际操作。"
                : "以下保留作品集中的完整截图。点击图片放大，横向表格可左右滑动。"}
            </p>
            <Gallery project={project} onImage={onImage} />
            <p className="detail-source">
              {project.sourceNote ??
                "材料来自《小丁-作品集》。截图中的互动数保留原始记录；账号、竞品与作品数据分别说明，不作为个人独立业绩。"}
            </p>
          </section>
        </div>
      </div>
      <section className="case-next page-gutter">
        <div>
          <span className="studio-eyebrow">KEEP EXPLORING</span>
          <ProjectLink project={next} onOpen={onProject}>
            <h2>
              {next.name} <ArrowUpRight size={30} />
            </h2>
          </ProjectLink>
        </div>
        <button type="button" className="text-link" onClick={onBack}>
          <ArrowLeft size={15} /> 返回个人首页
        </button>
      </section>
      <footer className="case-page-footer page-gutter">
        <span>© {new Date().getFullYear()} LaoDing</span>
        <a
          href={siteConfig.sourceUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          飞书作品集 <ArrowUpRight size={13} />
        </a>
      </footer>
    </main>
  );
}
