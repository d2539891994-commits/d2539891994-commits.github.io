import { useEffect, useRef, useState } from "react";
import { motion, useScroll } from "framer-motion";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import {
  feishuCollection,
  feishuProjects,
  siteConfig,
  type PortfolioImage,
} from "../data/content";
import { ProjectCover } from "../components/ProjectCover";
import { CaseShare } from "../components/CaseShare";
import { AccountsSection } from "./AccountsSection";
import { Gallery, Evidence, WorkflowNotes } from "./CasePage";

const chapters = [
  { id: "content", label: "内容作品" },
  { id: "research", label: "研究与脚本" },
  { id: "workflow", label: "制作流程" },
  { id: "accounts", label: "账号记录" },
];

export function FeishuCollectionPage({
  onBack,
  onImage,
  onRead,
}: {
  onBack: () => void;
  onImage: (image: PortfolioImage) => void;
  onRead: () => void;
}) {
  const ref = useRef<HTMLElement>(null);
  const [chapter, setChapter] = useState("content");
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end end"],
  });
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (visible[0]) setChapter(visible[0].target.id.replace("case-", ""));
      },
      { rootMargin: "-15% 0px -55% 0px", threshold: 0 },
    );
    ref.current?.querySelectorAll("[data-case-chapter]").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
  const jump = (id: string) => {
    setChapter(id);
    document.getElementById(`case-${id}`)?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth",
      block: "start",
    });
  };
  return (
    <main ref={ref} className="case-page case-page-feishu">
      <header className="case-nav page-gutter">
        <button type="button" className="case-back" onClick={onBack}>
          <ArrowLeft size={16} /><span>返回个人首页</span>
        </button>
        <span className="case-nav-name">LaoDing <span>/</span> CONTENT COLLECTION</span>
        <CaseShare project={feishuCollection} />
        <motion.span className="case-reading-progress" style={{ scaleX: scrollYProgress }} />
      </header>
      <div className="case-page-head page-gutter">
        <span className="studio-eyebrow">{feishuCollection.category}</span>
        <h1 id="case-title" tabIndex={-1}>{feishuCollection.name}</h1>
        <div className="case-head-bottom">
          <p>从教程内容到研究、脚本与制作流程，记录 AI 应用与知识内容的创作实践。</p>
          <a className="studio-button primary-button" href={siteConfig.sourceUrl} target="_blank" rel="noopener noreferrer">
            打开飞书原文 <ArrowUpRight size={16} />
          </a>
        </div>
      </div>
      <div className="case-cover-wrap page-gutter">
        <ProjectCover project={feishuCollection} />
      </div>
      <div className="collection-source page-gutter">
        <span>小丁 · 内容创作档案</span>
        <p>材料整理自飞书《小丁-作品集》，账号与作品数据沿用原始截图口径。</p>
      </div>
      <div className="case-page-body page-gutter" id="case-body">
        <aside className="case-chapter-nav collection-chapters" aria-label="作品集目录">
          {chapters.map((item, index) => (
            <button key={item.id} type="button" aria-current={chapter === item.id ? "location" : undefined} onClick={() => jump(item.id)}>
              <span>0{index + 1}</span>{item.label}
            </button>
          ))}
          <button type="button" onClick={onBack} className="chapter-return"><ArrowLeft size={12} /> 返回个人首页</button>
        </aside>
        <div className="case-narrative collection-narrative">
          {feishuProjects.map((project, index) => (
            <section key={project.id} id={`case-${project.id}`} data-case-chapter>
              <span className="studio-eyebrow">0{index + 1} / {chapters[index].label}</span>
              <div className="collection-group-heading">
                <h2>{project.name}</h2>
              </div>
              <p className="case-lead">{project.description}</p>
              <div className="collection-notes">
                {project.details.map((detail) => <div key={detail.title}><h3>{detail.title}</h3><p>{detail.text}</p></div>)}
              </div>
              {project.workflow && <WorkflowNotes />}
              <Gallery project={project} onImage={onImage} />
              {project.report && <Evidence onRead={onRead} />}
              <p className="detail-source">
                {project.sourceNote ?? "材料来自《小丁-作品集》。截图中的互动数保留原始记录；账号、竞品与作品数据分别说明，不作为个人独立业绩。"}
              </p>
            </section>
          ))}
          <section id="case-accounts" data-case-chapter className="collection-accounts">
            <AccountsSection onImage={onImage} />
          </section>
        </div>
      </div>
      <footer className="collection-footer page-gutter">
        <span>© {new Date().getFullYear()} LaoDing · 内容创作作品集</span>
        <button type="button" className="text-link" onClick={onBack}><ArrowLeft size={14} /> 回到个人首页，继续探索</button>
      </footer>
    </main>
  );
}
