import { ArrowUpRight } from "lucide-react";
import { FadeIn } from "../components/FadeIn";
import { accountImages, type PortfolioImage } from "../data/content";
export function AccountsSection({
  onImage,
}: {
  onImage: (image: PortfolioImage) => void;
}) {
  return (
    <section
      id="accounts"
      className="accounts-section"
      aria-labelledby="accounts-title"
    >
      <FadeIn>
        <div className="accounts-heading">
          <div>
            <span className="studio-eyebrow">04 / ACCOUNT CONTEXT</span>
            <h2 id="accounts-title">
              内容发生的地方<span>。</span>
            </h2>
          </div>
          <p>
            林粒粒呀 · 多平台内容
            <br />
            <span>账号背景以原始截图记录为准。</span>
          </p>
        </div>
      </FadeIn>
      <div className="account-grid">
        {accountImages.map((item, i) => (
          <FadeIn key={item.src} delay={i * 0.08}>
            <button
              type="button"
              className="account-item"
              onClick={() => onImage(item)}
              aria-label={`查看${item.caption}`}
            >
              <span className="account-label">
                {item.title}
                <ArrowUpRight size={20} />
              </span>
              <div className="account-image">
                <img
                  src={item.src}
                  alt={item.caption}
                  loading="lazy"
                  decoding="async"
                />
              </div>
            </button>
          </FadeIn>
        ))}
      </div>
      <p className="account-note">
        页面粉丝与互动数为截图中的账号信息，不代表个人独立业绩。
      </p>
    </section>
  );
}
