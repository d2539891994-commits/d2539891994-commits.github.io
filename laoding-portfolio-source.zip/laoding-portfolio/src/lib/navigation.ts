import { useCallback, useEffect, useRef, useState } from "react";
import { flushSync } from "react-dom";
import { projects, siteConfig, type Project } from "../data/content";

export const projectPath = (project: Project) => `/work/${project.id}/`;
export function projectAtLocation() {
  const id =
    window.location.pathname.match(
      /^\/work\/([a-z-]+)(?:\/|\/index\.html)?$/,
    )?.[1] ?? window.location.hash.match(/^#work\/([a-z-]+)$/)?.[1];
  return projects.find((project) => project.id === id) ?? null;
}

type PageTransition = {
  finished: Promise<void>;
  updateCallbackDone: Promise<void>;
  skipTransition: () => void;
};
type TransitionDocument = Document & {
  startViewTransition?: (update: () => void) => PageTransition;
};
type CoverRect = { left: number; top: number; width: number; height: number };
export type CoverFlight = {
  project: Project;
  from: CoverRect;
  to: CoverRect;
  toCase: boolean;
};
const rectOf = (element: Element | null): CoverRect | null => {
  if (!element) return null;
  const { left, top, width, height } = element.getBoundingClientRect();
  return width && height ? { left, top, width, height } : null;
};

export function usePortfolioNavigation(onNavigate: () => void) {
  const [project, setProject] = useState<Project | null>(projectAtLocation);
  const [flight, setFlight] = useState<CoverFlight | null>(null);
  const current = useRef(project);
  const homeFocus = useRef<HTMLElement | null>(null);
  const homeOrigin = useRef<string | null>(null);
  const transition = useRef<PageTransition | null>(null);
  const changing = useRef(false);
  const generation = useRef(0);
  current.current = project;

  const changePage = useCallback(
    async (next: Project | null, scroll: number | null, morph: boolean) => {
      const navigation = ++generation.current;
      changing.current = true;
      flushSync(() => setFlight(null));
      transition.current?.skipTransition();
      if (transition.current)
        await transition.current.updateCallbackDone.catch(() => {});
      if (navigation !== generation.current) return;
      const flightProject = next ?? current.current;
      const from = flightProject
        ? rectOf(
            document.querySelector(
              current.current
                ? ".case-cover-wrap .editorial-cover"
                : `.selected-section .cover-${flightProject.id}`,
            ),
          )
        : null;
      const update = () => {
        if (navigation !== generation.current) return;
        flushSync(() => {
          onNavigate();
          setProject(next);
        });
        const top = next
          ? 0
          : (scroll ??
            Math.max(
              0,
              (document.getElementById("projects")?.getBoundingClientRect()
                .top ?? 0) +
                window.scrollY -
                32,
            ));
        window.scrollTo({ top, behavior: "instant" });
        document.title = next ? `${next.name} — LaoDing` : siteConfig.title;
        if (next)
          document.getElementById("case-title")?.focus({ preventScroll: true });
        else if (homeFocus.current?.isConnected)
          homeFocus.current.focus({ preventScroll: true });
        else
          document
            .getElementById("projects-title")
            ?.focus({ preventScroll: true });
      };
      const doc = document as TransitionDocument;
      if (
        doc.startViewTransition &&
        morph &&
        !window.matchMedia("(prefers-reduced-motion: reduce)").matches
      ) {
        const active = doc.startViewTransition(update);
        transition.current = active;
        await active.finished.catch(() => {});
        if (transition.current === active) transition.current = null;
      } else {
        update();
        if (
          morph &&
          from &&
          flightProject &&
          !window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ) {
          const to = rectOf(
            document.querySelector(
              next
                ? ".case-cover-wrap .editorial-cover"
                : `.selected-section .cover-${flightProject.id}`,
            ),
          );
          if (to) {
            flushSync(() =>
              setFlight({
                project: flightProject,
                from,
                to,
                toCase: Boolean(next),
              }),
            );
            return;
          }
        }
      }
      if (navigation === generation.current) changing.current = false;
    },
    [onNavigate],
  );

  useEffect(() => {
    const oldRestoration = window.history.scrollRestoration;
    window.history.scrollRestoration = "manual";
    const legacy = projectAtLocation();
    if (legacy && window.location.hash.startsWith("#work/"))
      window.history.replaceState(
        window.history.state,
        "",
        projectPath(legacy),
      );
    document.title = legacy ? `${legacy.name} — LaoDing` : siteConfig.title;
    const onPop = (event: PopStateEvent) => {
      const next = projectAtLocation();
      if (next?.id === current.current?.id && !changing.current) return;
      const morph = !next && current.current?.id === homeOrigin.current;
      if (!next && morph) window.scrollTo({ top: 0, behavior: "instant" });
      void changePage(
        next,
        typeof event.state?.homeScroll === "number"
          ? event.state.homeScroll
          : null,
        morph,
      );
    };
    const onHash = () => {
      if (!window.location.hash.startsWith("#work/")) return;
      const next = projectAtLocation();
      if (!next || next.id === current.current?.id) return;
      window.history.replaceState(window.history.state, "", projectPath(next));
      void changePage(next, 0, false);
    };
    window.addEventListener("popstate", onPop);
    window.addEventListener("hashchange", onHash);
    return () => {
      window.history.scrollRestoration = oldRestoration;
      window.removeEventListener("popstate", onPop);
      window.removeEventListener("hashchange", onHash);
      transition.current?.skipTransition();
    };
  }, [changePage]);

  const openProject = useCallback(
    (next: Project) => {
      if (changing.current || next.id === current.current?.id) return;
      changing.current = true;
      let morph = false;
      if (!current.current) {
        homeFocus.current = document.activeElement as HTMLElement | null;
        homeOrigin.current = next.id;
        window.history.replaceState(
          { ...window.history.state, homeScroll: window.scrollY },
          "",
          window.location.href,
        );
        const cover = document
          .querySelector(`.selected-section .cover-${next.id}`)
          ?.getBoundingClientRect();
        morph = Boolean(
          cover && cover.top < window.innerHeight && cover.bottom > 0,
        );
        window.history.pushState(
          { fromPortfolio: true },
          "",
          projectPath(next),
        );
      } else
        window.history.replaceState(
          window.history.state,
          "",
          projectPath(next),
        );
      void changePage(next, 0, morph);
    },
    [changePage],
  );

  const returnHome = useCallback(() => {
    if (changing.current) return;
    if (window.history.state?.fromPortfolio) window.history.back();
    else {
      window.history.replaceState(null, "", "/#projects");
      void changePage(null, null, false);
    }
  }, [changePage]);
  const finishFlight = useCallback(() => {
    setFlight(null);
    changing.current = false;
  }, []);
  return { project, openProject, returnHome, flight, finishFlight };
}
