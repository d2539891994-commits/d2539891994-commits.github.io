import { useCallback, useState } from "react";
import { AnimatePresence, MotionConfig } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { HeroSection } from "./sections/HeroSection";
import { AboutSection } from "./sections/AboutSection";
import { FeishuCollectionPage } from "./sections/FeishuCollectionPage";
import { ProjectsSection } from "./sections/ProjectsSection";
import { Dialog } from "./components/Dialog";
import { ContactDialog } from "./components/ContactDialog";
import { CasePage } from "./sections/CasePage";
import { CoverTransition } from "./components/CoverTransition";
import { usePortfolioNavigation } from "./lib/navigation";
import { type PortfolioImage } from "./data/content";
import reportBlocks from "./data/report.json";

type ActiveView =
  | { kind: "image"; image: PortfolioImage }
  | { kind: "report" }
  | { kind: "contact" }
  | null;
type ReportBlock = {
  kind: string;
  text?: string;
  src?: string;
  alt?: string;
  rows?: string[][];
};

export default function App() {
  const [active, setActive] = useState<ActiveView>(null);
  const close = useCallback(() => setActive(null), []);
  const {
    project: routeProject,
    openProject,
    returnHome,
    flight,
    finishFlight,
  } = usePortfolioNavigation(close);
  const openImage = useCallback(
    (image: PortfolioImage) => setActive({ kind: "image", image }),
    [],
  );
  const readReport = useCallback(() => setActive({ kind: "report" }), []);
  const openContact = useCallback(() => setActive({ kind: "contact" }), []);
  return (
    <MotionConfig reducedMotion="user">
      <a className="skip-link" href={routeProject ? "#case-body" : "#projects"}>
        {routeProject ? "跳到正文" : "跳到作品与项目"}
      </a>
      <div
        className={
          flight ? `cover-is-flying flying-${flight.project.id}` : undefined
        }
      >
        <main
          id="top"
          hidden={Boolean(routeProject)}
          className="site-wrapper bg-ink text-mist"
          style={{ overflowX: "clip" }}
        >
          <HeroSection onContact={openContact} />
          <ProjectsSection onProject={openProject} />
          <AboutSection onContact={openContact} />
        </main>
        {routeProject?.layout === "collection" ? (
          <FeishuCollectionPage
            onBack={returnHome}
            onImage={openImage}
            onRead={readReport}
          />
        ) : routeProject && (
          <CasePage
            key={routeProject.id}
            project={routeProject}
            onBack={returnHome}
            onProject={openProject}
            onImage={openImage}
            onRead={readReport}
          />
        )}
      </div>
      {flight && (
        <CoverTransition
          key={`${flight.project.id}-${flight.toCase}`}
          flight={flight}
          onComplete={finishFlight}
        />
      )}
      <AnimatePresence mode="wait">
        {active?.kind === "contact" ? (
          <ContactDialog key="contact" onClose={close} />
        ) : active?.kind === "image" ? (
          <Dialog
            key={active.image.src}
            onClose={close}
            titleId="image-dialog-title"
            className={`image-dialog image-dialog-${active.image.shape}`}
          >
            {routeProject && (
              <button className="back-to-work" type="button" onClick={close}>
                <ArrowLeft size={16} /> {routeProject.layout === "collection" ? "返回作品集" : "返回案例"}
              </button>
            )}
            <h2 id="image-dialog-title">{active.image.title}</h2>
            <p className="image-caption">
              {active.image.caption}
              {active.image.shape === "wide" && (
                <span className="image-pan-hint">横向表格可左右滑动查看</span>
              )}
            </p>
            <div className="full-image">
              <img
                src={active.image.src}
                alt={active.image.caption}
                style={
                  active.image.width
                    ? { minWidth: active.image.width }
                    : undefined
                }
              />
            </div>
          </Dialog>
        ) : active?.kind === "report" ? (
          <Dialog
            key="report"
            onClose={close}
            titleId="report-title"
            className="report-dialog"
          >
            <button className="back-to-work" type="button" onClick={close}>
              <ArrowLeft size={16} /> {routeProject?.layout === "collection" ? "返回作品集" : "返回案例"}
            </button>
            <span className="eyebrow">CONTENT BREAKDOWN / 2026.10.20</span>
            <h2 id="report-title" className="hero-heading">
              Codex 安装教程
              <br />
              内容拆解报告
            </h2>
            <p className="dialog-intro">
              从选题与文案结构，看到数据能够确认的表现。网页正文整理自飞书作品集的原报告附件。
            </p>
            <article className="report-body">
              {(reportBlocks as ReportBlock[]).map((block, index) => {
                if (block.kind === "heading")
                  return <h3 key={index}>{block.text}</h3>;
                if (block.kind === "table")
                  return (
                    <div className="report-table-wrap" key={index}>
                      <table>
                        <thead>
                          <tr>
                            {block.rows?.[0]?.map((cell, i) => (
                              <th scope="col" key={i}>
                                {cell}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {block.rows?.slice(1).map((row, i) => (
                            <tr key={i}>
                              {row.map((cell, j) => (
                                <td key={j}>{cell}</td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                if (block.kind === "image")
                  return (
                    <img
                      key={index}
                      src={block.src}
                      alt={block.alt}
                      loading="lazy"
                    />
                  );
                return <p key={index}>{block.text}</p>;
              })}
            </article>
            <p className="detail-source">
              统计日期与口径沿用原报告。作品表现、内容判断和评论样本分别解读；评论去重后为39条主评文本（n=39）。
            </p>
          </Dialog>
        ) : null}
      </AnimatePresence>
    </MotionConfig>
  );
}
