# LaoDing — 个人网站

使用 React、TypeScript、Tailwind CSS、Framer Motion 和 Lucide React 构建的个人网站。首页展示个人形象、核心优势，以及滚动叠加的作品集与项目卡片。飞书《小丁-作品集》集中为一个内容创作档案，衣序 CHROMA 是独立项目；可在同一级继续添加其他项目。

## 本地运行

需要 Node.js 22 或更新版本。

```bash
npm ci
npm run dev
```

检查与构建：

```bash
npm run typecheck
npm run build
npm run preview
```

输出目录为 `dist/`，可部署至任意静态网站托管服务，不需要 API Key 或数据库。构建还会生成可下载的单文件 HTML 和源码 ZIP，分别发布到 `/downloads/laoding-portfolio-html.zip` 与 `/downloads/laoding-portfolio-source.zip`。

## 单文件 HTML 与公开源码

```bash
npm run export:html
npm run export:source
```

公开 HTML 下载为 ZIP 压缩包，解压后得到单文件 HTML、使用说明与许可证，避免托管平台给 HTML 自动注入脚本。

`exports/LaoDing-个人网站.html` 内嵌页面脚本、CSS、图片、Kanit 字体和 CHROMA 操作短片，无需安装依赖即可用浏览器打开。案例采用同一文件内的 `#work/...` 地址，保留返回、放大原图和联系弹窗。外部飞书原文档与 CHROMA 在线编辑器仍需网络；单文件不包含独立编辑器本体。

`exports/laoding-portfolio-source.zip` 包含可维护的 React/TypeScript 源码、构建与导出脚本、MIT 许可和素材说明。页脚提供匿名下载入口。ZIP 不包含托管账号身份、密钥、环境变量、Git 元数据、依赖或原始飞书导出。开源以公开源码下载的方式交付，当前未创建 GitHub 仓库。

HTML 是可离线查看的文件；公开网址的可达性取决于实际托管和访问网络，导出文件本身不会解决旧域名在部分网络下的连接问题。

## 页面与交互

- 首页：超大渐变标题、中央全身人物与左下核心优势。全身形象采用站主提供的穿搭图，并通过内置 imagegen 分离背景；从头发到鞋子完整显示，保留鼠标跟随、水平拖动和透视倾斜。交互由透明图片实现，非可环绕查看的三维模型。素材说明见 `docs/ASSETS.md`。
- 作品与项目：大卡片随滚动依次覆盖，前一张轻微缩小，电脑和竖屏手机均可叠加。短屏与减少动态效果模式采用顺序阅读。`src/data/content.ts` 的 `showcases` 列表控制首页入口。
- 关于我：人物照片卡片随鼠标位置绕 X/Y 轴倾斜，移开后弹簧平滑复位；静止外框负责命中检测，触屏与减少动态效果模式保持静止。
- 联系入口：首屏和关于我提供「CONTACT ME」渐变按钮，共用联系卡片弹窗。按站主要求先公开框架，联系方式保持留空，显示「联系方式稍后公开」。之后在 `src/data/contact.ts` 配置邮箱、微信号或联系页面即可；未配置时不渲染发送、复制或外部跳转操作。
- 内容创作作品集：`/work/feishu/` 集中展示教程、研究分镜、制作与工具、账号记录，以及完整拆解报告。首页不再分散展示这些材料。
- 独立案例：`/work/content/`、`/work/chroma/`、`/work/research/`、`/work/workflow/`。每页有章节导航、阅读进度、分享与相关案例入口；旧版 `#work/...` 链接保持兼容。
- 封面转场：支持浏览器使用 View Transitions；其他浏览器使用 Framer Motion 封面放大与收回。返回时恢复首页浏览位置，减少动态效果设置下直接切换。
- 操作预览：CHROMA 提供约10秒的真实操作节选、中文说明字幕和章节定位，默认不自动播放。
- 原始图片仍完整保留。首页封面为截图局部的视觉编排，不能替代证据材料。

## 内容结构

- 账号展示：Bilibili、小红书、抖音、视频号四张账号主页。
- 教程内容：六张原始作品截图。
- 研究与拆解：受众画像、竞品账号分析、选题库、Codex 拆解分镜，以及网页内阅读的 Codex 视频拆解报告。
- 在线工具：衣序 CHROMA 视频编辑器，提供在线体验链接，支持已有视频的播放、裁剪与导出；剪辑免费，上传新穿搭自动换装尚未接入。
- AI 工作流与素材管理：工具界面、两组音效库截图，以及附带学习资料中的四步直播切片流程。

原飞书中没有正文或素材的栏目不渲染。网站不保留旧版虚构客户项目、3D 服务报价、空联系表单或“待补”内容框。

## 修改内容

- `src/data/content.ts`：名字、介绍、图片、项目分组与说明。
- `src/data/report.json`：由原报告正文与表格整理的网页阅读数据；不包含本地文件路径附录。
- `public/images/portfolio/`：经完整画面压缩的作品截图与原报告图表。
- `src/styles.css`：全站基础样式；`src/reference-hero.css`：参考式首屏；`src/showcase.css`：首页项目卡片与作品集归档页；`src/dialogs.css`：证据材料与报告阅读样式。
- `src/components/ProjectCover.tsx`：作品封面的视觉编排。
- `src/sections/CasePage.tsx`：案例正文、原始材料与相关案例。
- `src/sections/FeishuCollectionPage.tsx`：飞书作品集的统一归档页面。
- `src/lib/navigation.ts`：独立地址、历史记录与滚动恢复。
- `public/media/`：CHROMA 操作短片、封面与字幕；不含教程原视频。
- `scripts/prerender.mjs`：构建时为项目列表生成可直接刷新的静态入口及分享元信息。
- `scripts/export-html.mjs`：把页面编译为内嵌资源的单个 HTML，独立文件采用 hash 路由。
- `scripts/export-source.mjs`：用 Node.js 生成源码 ZIP，不需额外的压缩工具。
- `index.html`：首页标题、描述与社交分享信息。

图片详情支持放大；横向表格可在图片容器中左右滑动。弹窗支持 Escape、焦点控制与返回作品。尊重系统的减少动态效果设置。

## 数据和出处

账号、竞品和作品互动数据分别解释，不作为个人独立业绩。拆解报告保留原统计日期 2026-10-20；评论样本为去重后的39条主评文本，n=39。拆解分镜按原片整理，不冒充原视频原创拍摄脚本。工具界面不代表自研或已验证的采集结果；直播切片流程标为学习资料并保留来源。

## 开源与素材

代码采用 MIT 许可。作品截图、第三方账号内容、字体和学习资料保留各自版权，不能因代码开源而自动转授。源码包用于继续维护此个人网站；将代码用作其他项目时应替换个人作品素材。完整说明见 [docs/ASSETS.md](docs/ASSETS.md)。

Kanit 的300至900正常字重使用本地 WOFF2，随包保留 SIL OFL 1.1 许可证，不向 Google Fonts 请求字体。

源码包排除 `.git`、`.openai`、`node_modules`、`dist`、`artifacts`、环境变量与原始飞书导出。当前未创建公开 GitHub 仓库。

## 部署

使用 `npm run build`，发布整个 `dist/`，包含 `work/*/index.html`。更换域名时用 `SITE_ORIGIN=https://your-domain.example npm run build` 更新案例的 canonical 和分享地址。当前路由以域名根目录为基准；部署到子目录时，还需调整路由前缀、素材路径与 Vite 的 `base`。使用 Sites 的原有项目进行后续发布时，请保留该项目身份和当前公开访问设置。

当前仍使用需求指定的 Tailwind 3 工具链。更新依赖时检查 `npm audit`，避免未经检查就强制升级主版本。
